package com.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ProyectoApplication.class)
class ProyectoApplicationTests {

    @Test
    void contextLoads() {
    }
}
