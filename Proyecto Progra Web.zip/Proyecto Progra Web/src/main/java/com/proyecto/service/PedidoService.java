package com.proyecto.service;

import com.proyecto.entity.Pedido;
import java.util.List;

public interface PedidoService {
    List<Pedido> obtenerPedidosPorCliente(Long clienteId);
    Pedido buscarPorId(Long id);
}

