package com.proyecto.controller;

import com.proyecto.domain.Cliente;
import com.proyecto.entity.DetallePedido;
import com.proyecto.entity.Pedido;
import com.proyecto.model.CarritoItem;
import com.proyecto.repository.PedidoRepository;
import com.proyecto.service.ClienteService;
import com.proyecto.service.EmailService;
import com.proyecto.service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/pedido")
@SessionAttributes({"carrito", "clienteAutenticado"})
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private PedidoService pedidoService;

    // ====== PUNTO 5: Confirmación de pedido mejorada ======
    @PostMapping("/confirmar")
    public String confirmarPedido(@RequestParam String direccion,
                                  @ModelAttribute("carrito") List<CarritoItem> carrito,
                                  @AuthenticationPrincipal UserDetails userDetails,
                                  SessionStatus status,
                                  Model model) {

        // Buscar cliente logueado
        Cliente cliente = clienteService.buscarPorEmail(userDetails.getUsername());

        // Crear nuevo pedido
        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setFecha(LocalDate.now());

        double total = 0;
        List<DetallePedido> detalles = new ArrayList<>();
        for (CarritoItem item : carrito) {
            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(pedido);
            detalle.setProducto(item.getProducto());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecio(item.getProducto().getPrecio());
            detalles.add(detalle);
            total += item.getProducto().getPrecio() * item.getCantidad();
        }
        pedido.setDetalles(detalles);
        pedido.setTotal(total);
        pedidoRepository.save(pedido);

        // Enviar correo de confirmación
        String asunto = "Confirmación de pedido #" + pedido.getId();
        String mensaje = "Hola " + cliente.getNombre() + ",\n\n" +
                "Gracias por tu compra. Tu pedido #" + pedido.getId() + " ha sido procesado correctamente.\n" +
                "Fecha: " + pedido.getFecha() + "\n" +
                "Total: $" + pedido.getTotal() + "\n\n" +
                "Detalles de tu pedido:\n" +
                pedido.getDetalles().stream()
                        .map(det -> "- " + det.getProducto().getNombre() + " x" + det.getCantidad())
                        .reduce("", (a, b) -> a + "\n" + b) +
                "\n\n¡Gracias por confiar en nosotros!";
        emailService.enviarCorreo(cliente.getEmail(), asunto, mensaje);

        // Limpiar carrito
        status.setComplete();

        // Pasar datos a la vista
        model.addAttribute("pedido", pedido);
        return "confirmacion";
    }

    // ====== PUNTO 7: Ver historial de pedidos ======
    @GetMapping("/historial")
    public String verHistorial(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        Cliente cliente = clienteService.buscarPorEmail(userDetails.getUsername());
        List<Pedido> pedidos = pedidoService.obtenerPedidosPorCliente(cliente.getId());
        model.addAttribute("pedidos", pedidos);
        return "historial";
    }

    @GetMapping("/{id}")
    public String verDetallePedido(@PathVariable Long id, Model model, @AuthenticationPrincipal UserDetails userDetails) {
        Pedido pedido = pedidoService.buscarPorId(id);
        Cliente cliente = clienteService.buscarPorEmail(userDetails.getUsername());

        // Seguridad: que el pedido pertenezca al cliente
        if (!pedido.getCliente().getId().equals(cliente.getId())) {
            return "redirect:/pedido/historial";
        }

        model.addAttribute("pedido", pedido);
        return "detalle_pedido";
    }
}
